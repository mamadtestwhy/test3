import React from 'react';
import AppRouter from './app/routes/router';

const App: React.FC = () => {
  return <AppRouter />;
};

export default App;
