import React from 'react';
import { useSelector } from 'react-redux';
import { RootState } from '../../app/store';

export const ServicesSection: React.FC = () => {
  const services = useSelector((state: RootState) => state.home.services);

  if (!services || services.length === 0) {
    return (
      <section id="services" className="py-20 bg-gradient-to-b from-purple-900 to-black text-white">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-10">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">خدمات من</h2>
            <p className="text-lg md:text-xl max-w-2xl mx-auto text-gray-300">
              ارائه خدمات حرفه‌ای در زمینه عکاسی و طراحی
            </p>
          </div>
          <div className="text-center text-gray-400">در حال بارگذاری خدمات...</div>
        </div>
      </section>
    );
  }

  return (
    <section id="services" className="py-20 bg-black text-white">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">خدمات من</h2>
          <p className="text-lg md:text-xl max-w-2xl mx-auto text-gray-300">
            ارائه خدمات حرفه‌ای در زمینه عکاسی و طراحی
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white/10 backdrop-blur-md p-8 rounded-3xl shadow-md hover:shadow-2xl hover:scale-105 transition-all duration-300 group"
            >
              <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-pink-500 rounded-full flex items-center justify-center text-white mb-6 group-hover:rotate-12 transition-transform duration-300">
                {service.icon}
              </div>
              <h3 className="text-xl font-bold mb-4">{service.title}</h3>
              <p className="text-gray-300 mb-6 leading-relaxed">{service.description}</p>
              <ul className="space-y-2">
                {service.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center gap-2 text-sm text-gray-300">
                    <div className="w-2 h-2 bg-pink-500 rounded-full"></div>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
