import { Camera, Palette, Grid, Award } from "lucide-react";

export const categories = [
  "همه",
  "عکاسی طبیعت",
  "معماری",
  "طراحی گرافیک",
  "UI/UX",
  "برندینگ",
];

export const portfolioItems = [
  {
    id: 1,
    title: "طلوع در صحرا",
    category: "عکاسی طبیعت",
    image:
      "https://images.pexels.com/photos/714258/pexels-photo-714258.jpeg?auto=compress&cs=tinysrgb&w=800",
    likes: 320,
    views: 1850,
    description: "طلوع آفتاب بر فراز تپه‌های شنی صحرا",
    tags: ["طلوع", "صحرا", "طبیعت"],
  },
  {
    id: 2,
    title: "معماری شیشه‌ای",
    category: "معماری",
    image:
      "https://images.pexels.com/photos/323705/pexels-photo-323705.jpeg?auto=compress&cs=tinysrgb&w=800",
    likes: 280,
    views: 1320,
    description: "نمای ساختمان مدرن با دیوارهای شیشه‌ای",
    tags: ["مدرن", "شیشه‌ای", "شهری"],
  },
  {
    id: 3,
    title: "جنگل مه‌آلود",
    category: "عکاسی طبیعت",
    image:
      "https://images.pexels.com/photos/4827/nature-forest-trees-fog.jpeg?auto=compress&cs=tinysrgb&w=800",
    likes: 415,
    views: 2200,
    description: "درختان بلند در میان مه صبحگاهی",
    tags: ["جنگل", "مه", "آرامش"],
  },
  {
    id: 4,
    title: "طراحی لوگو مدرن",
    category: "طراحی گرافیک",
    image:
      "https://images.pexels.com/photos/2528118/pexels-photo-2528118.jpeg?auto=compress&cs=tinysrgb&w=800",
    likes: 305,
    views: 1420,
    description: "طراحی لوگو مدرن با الهام از اشکال هندسی",
    tags: ["لوگو", "مدرن", "هندسی"],
  },
  {
    id: 6,
    title: "ساحل آرام",
    category: "عکاسی طبیعت",
    image:
      "https://images.pexels.com/photos/533923/pexels-photo-533923.jpeg?auto=compress&cs=tinysrgb&w=800",
    likes: 450,
    views: 2400,
    description: "خط ساحلی آرام با موج‌های ملایم",
    tags: ["دریا", "ساحل", "آرامش"],
  },
  {
    id: 7,
    title: "هویت بصری رستوران",
    category: "برندینگ",
    image:
      "https://images.pexels.com/photos/288477/pexels-photo-288477.jpeg?auto=compress&cs=tinysrgb&w=800",
    likes: 268,
    views: 1290,
    description: "طراحی هویت بصری کامل برای یک رستوران مدرن",
    tags: ["برند", "رستوران", "هویت"],
  },
  {
    id: 9,
    title: "اپلیکیشن فروشگاهی",
    category: "UI/UX",
    image:
      "https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=800",
    likes: 340,
    views: 1650,
    description: "طراحی رابط کاربری برای اپلیکیشن فروشگاهی مدرن",
    tags: ["UI", "اپلیکیشن", "فروشگاه"],
  },
];

export const services = [
  {
    icon: <Camera className="w-8 h-8" />,
    title: "عکاسی حرفه‌ای",
    description: "عکاسی در سبک‌های متنوع با کیفیت بالا",
    features: ["طبیعت", "شهری", "معماری", "صنعتی"],
  },
  {
    icon: <Palette className="w-8 h-8" />,
    title: "طراحی گرافیک",
    description: "خلق طراحی‌های مدرن و خلاقانه برای برند شما",
    features: ["لوگو", "پوستر", "بسته‌بندی", "تبلیغات"],
  },
  {
    icon: <Grid className="w-8 h-8" />,
    title: "طراحی UI/UX",
    description: "طراحی رابط کاربری زیبا و بهینه برای وب و موبایل",
    features: ["وب‌سایت", "اپلیکیشن", "داشبورد", "پروتوتایپ"],
  },
  {
    icon: <Award className="w-8 h-8" />,
    title: "برندینگ",
    description: "ایجاد هویت بصری قوی و متمایز برای کسب‌وکار",
    features: ["هویت بصری", "راهنمای برند", "کارت ویزیت", "ست اداری"],
  },
];



export const stats = [
  { number: '500+', label: 'پروژه تکمیل شده' },
  { number: '50+', label: 'مشتری راضی' },
  { number: '10', label: 'سال تجربه' },
  { number: '25', label: 'جایزه دریافتی' },
];
