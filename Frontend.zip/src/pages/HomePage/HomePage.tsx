import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
  toggleMenu,
  setActiveCategory,
  setViewMode,
  setSelectedImage,
  setIsVisible,
  setServices,
} from '../../features/home/homeSlice';
import { RootState } from '../../app/store';
import { portfolioItems, services } from '../../shared/api/api';
import { Header } from '../../shared/ui/Header';
import { HeroSection } from '../../shared/ui/Hero Section';
import { PortfolioSection } from '../../shared/ui/Portfolio Section';
import { ServicesSection } from '../../shared/ui/Services Section';
import { AboutSection } from '../../shared/ui/About Section';
import { ContactSection } from '../../shared/ui/Contact Section ';
import { Footer } from '../../shared/ui/Footer';
import { ImageModal } from '../../shared/ui/Image Modal';
import { PortfolioItem } from '../../shared/types/interface';

export const HomePage: React.FC = () => {
  const dispatch = useDispatch();
  const { isMenuOpen, activeCategory, viewMode, selectedImage, isVisible } = useSelector(
    (state: RootState) => state.home
  );

  useEffect(() => {
    dispatch(setIsVisible(true));
    dispatch(setServices(services));
  }, [dispatch]);

  const filteredItems =
    activeCategory === 'همه'
      ? portfolioItems
      : portfolioItems.filter((item) => item.category === activeCategory);

  const openModal = (item: PortfolioItem) => {
    dispatch(setSelectedImage(item));
  };

  const closeModal = () => {
    dispatch(setSelectedImage(null));
  };

  

  return (
    <div className="font-sans bg-gray-50 text-gray-800 rtl overflow-x-hidden antialiased">
      <Header isMenuOpen={isMenuOpen} toggleMenu={() => dispatch(toggleMenu())} />
      <HeroSection isVisible={isVisible} />
      <PortfolioSection
        activeCategory={activeCategory}
        viewMode={viewMode}
        filteredItems={filteredItems}
        setActiveCategory={(category: string) => dispatch(setActiveCategory(category))}
        setViewMode={(mode: 'grid' | 'list') => dispatch(setViewMode(mode))}
        openModal={openModal}
      />
      <ServicesSection />
      <AboutSection />
      <ContactSection />
      <Footer />
      <ImageModal selectedImage={selectedImage} closeModal={closeModal} />
    </div>
  );
};