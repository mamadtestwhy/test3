
import { HomePage } from './pages/HomePage/HomePage';
const App: React.FC = () => {


  return (
    <HomePage />
  );
};

export default App;